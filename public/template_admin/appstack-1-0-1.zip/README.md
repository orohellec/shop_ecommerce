# AppStack - Responsive Admin Template

Thanks for buying. Navigate to `docs/documentation.html` to get started.
