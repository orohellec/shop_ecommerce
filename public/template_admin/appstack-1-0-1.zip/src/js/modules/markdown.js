import markdown from 'markdown'
import 'bootstrap-markdown/js/bootstrap-markdown.js'

window.markdown = markdown.markdown
