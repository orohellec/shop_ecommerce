import feather from 'feather-icons'

feather.replace()
