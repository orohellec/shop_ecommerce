import ApexCharts from 'apexcharts'

window.ApexCharts = ApexCharts;

window.Apex = {
  colors:['#0cc2aa', '#5fc27e', '#fcc100', '#f44455', '#5b7dff']
};
