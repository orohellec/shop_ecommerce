import toastr from 'toastr/toastr'

window.toastr = toastr;
